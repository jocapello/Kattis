import math
n=int(input())
for i in range(n):
    Cals=0
    Cals=int(input())
    Cals=Cals/400
    print(math.ceil(Cals))
