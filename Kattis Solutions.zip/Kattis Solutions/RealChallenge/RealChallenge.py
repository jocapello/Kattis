# import the math module  
import math  
  
n=int(input())
Length=math.sqrt(n)
print(Length*4)