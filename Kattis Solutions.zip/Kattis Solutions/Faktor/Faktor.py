A,B = map(int,input().split())
C = (A*(B-1))+1
print(C)