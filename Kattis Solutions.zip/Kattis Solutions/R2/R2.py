A,B, = map(int,input().split())
C=(B*2)-A
print(C)