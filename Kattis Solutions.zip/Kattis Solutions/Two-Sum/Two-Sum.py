'''
Date : 01-07-2022
Solution to Two-Sum 
By Jordan Capello

Written in Python
'''
n = list(map(int,input().split())) 
print(sum(n))
