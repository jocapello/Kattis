lst=[n for n in input().split('-')]  
letters = [word[0] for word in lst]
letters2 = list(letters)
print(''.join(letters2))
