'''
Date : 01-08-2022
Solution to Greetings
By Jordan Capello

Written in Python
'''
n = list(input())
print('h'+'e'*2*(n.count('e'))+'y')
