n = input()
if n == "OCT 31":
    print ("yup")
elif n == "DEC 25":
    print ("yup")
    
else:
    print("nope")