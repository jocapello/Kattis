a = int(input())
b = int(input())
d = 0
for i in range(int (b)):
    c = int(input())
    d = d + a - c 
d=d+a  
print(d)