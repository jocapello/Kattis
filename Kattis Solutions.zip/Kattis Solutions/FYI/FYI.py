'''
Date : 01-08-2022
Solution to FYI
By Jordan Capello

Written in Python
'''
n = list(input())
if n[0] == '5' and n[1] == '5' and n[2] == '5':
    print(1)
else:
    print(0)

    
