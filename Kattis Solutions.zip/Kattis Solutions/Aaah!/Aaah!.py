n = input()
x = input()
if len(n)>=len(x):
    print("go")
else:
    print("no")