A,B = map(int,input().split())
C,D = map(int,input().split())
E,F = map(int,input().split())
