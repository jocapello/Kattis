n = int(input())
if n % 2==0:
    print("Bob")
else:
    print("Alice")