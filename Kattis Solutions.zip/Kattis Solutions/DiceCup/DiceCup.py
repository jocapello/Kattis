'''
Date : 01-08-2022
Solution to Dice Cup
By Jordan Capello

Written in Python
'''
# from statistics import multimode
# import numpy as np

# a,b = (map(int,input().split())) 
# r = [[0 for x in range(int(a))] for y in range(b)]
# for i in range(int(b)):
#     for j in range(int(a)):
#         r[i][j] = (i+1)+(1+j)

# r = np.array(r).flatten()
# print('\n'.join(map(str,multimode(r))))
    
a,b = (map(int,input().split())) 

perm = a*b


    