A,B, = map(int,input().split())
for i in range(A):
    C = input()
print(B)