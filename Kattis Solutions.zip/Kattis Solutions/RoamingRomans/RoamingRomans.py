n = float(input())
c = 5280/4854*1000*n
print(round(c))