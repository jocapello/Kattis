'''
Date : 01-07-2022
Solution to Jack-O'-Lantern Juxtaposition
By Jordan Capello

Written in Python
'''
r = list(map(int,input().split())) 
print(r[0]*r[1]*r[2])
