'''
Date : 01-07-2022
Solution to N-sum
By Jordan Capello

Written in Python
'''
n = input()
r = list(map(int,input().split())) 
print(sum(r))

