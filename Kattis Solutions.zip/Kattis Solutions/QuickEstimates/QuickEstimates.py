n = int(input())
for i in range(n):
    A = input()
    print(len(A))