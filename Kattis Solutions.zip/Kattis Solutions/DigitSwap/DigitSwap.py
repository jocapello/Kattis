'''
Date : 01-08-2022
Solution to Digit Swap
By Jordan Capello

Written in Python
'''
n = list(input())
print(n[1]+n[0])

    
