import math
A,B = map(int,input().split())
Sin=math.hypot(A,B)
print(Sin)
