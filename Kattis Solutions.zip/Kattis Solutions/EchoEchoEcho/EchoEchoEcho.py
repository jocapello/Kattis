'''
Date : 01-08-2022
Solution to Echo Echo Echo
By Jordan Capello

Written in Python
'''
n = (input())
print((n+" ") * 3)
    
