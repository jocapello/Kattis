n = int(input())

ReallyBigFuckingList=["0 1", "1 1", "1 2", "2 3", "3 5", "5 8", "8 13", "13 21", "21 34", "34 55", "55 89", "89 144", "144 233", "233 377", "377 610", "610 987", "987 1597", "1597 2584", "2584 4181", "4181 6765", "6765 10946", "10946 17711", "17711 28657", "28657 46368", "46368 75025", "75025 121393", "121393 196418", "196418 317811", "317811 514229", "514229 832040", "832040 1346269", "1346269 2178309", "2178309 3524578", "3524578 5702887", "5702887 9227465", "9227465 14930352", "14930352 24157817", "24157817 39088169", "39088169 63245986", "63245986 102334155", "102334155 165580141", "165580141 267914296", "267914296 433494437", "433494437 701408733", "701408733 1134903170"]
print(ReallyBigFuckingList[n-1])

# Mystring="A"
# Plist=[]

# for p in range(n):

#     Mylist=[char for char in Mystring]  
#     for i in range(len(Mylist)):
#         if Mylist[i] == 'B':

#             Mylist[i]= 'BA'
#     for w in range(len(Mylist)):
#         if Mylist[w] == 'A':
#             Mylist[w]= 'B'
#     Mystring=''.join(Mylist)

#     TempList=[char for char in Mystring]  
#     x=TempList.count('A')
#     y=TempList.count('B')
#     w=x,y,' '
#     Plist.append(w)

#     print('')
#     print('')
#     print(p)

#     print(Plist)
#     print('')
