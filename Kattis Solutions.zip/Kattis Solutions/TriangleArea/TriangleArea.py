'''
Date : 01-08-2022
Solution to Triangle Area
By Jordan Capello

Written in Python
'''
n = list(map(int,input().split())) 
ans = (n[0]*n[1])/2
print('{:.7f}'.format((ans)))
    
