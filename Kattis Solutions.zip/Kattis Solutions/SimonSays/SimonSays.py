n=int(input())
for i in range(n):
    String = input()
    if String == "simon says":
        print("yes")
        print(String)
    else:
        print(" ")

