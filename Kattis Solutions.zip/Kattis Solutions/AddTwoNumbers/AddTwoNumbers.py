'''
Date : 01-08-2022
Solution to Add Two Numbers
By Jordan Capello

Written in Python
'''
a,b = map(int,input().split())
print(a+b)


